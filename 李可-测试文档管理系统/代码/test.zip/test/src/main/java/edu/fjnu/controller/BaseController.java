package edu.fjnu.controller;

public class BaseController {
}
