/**
 * Created by 傅彰炜 on 2018/1/17.
 */
$(document).ready(function() {
    $(".title").find("p").text("修改员工信息");
})