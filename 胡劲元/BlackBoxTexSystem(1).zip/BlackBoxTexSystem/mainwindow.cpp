#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>
#include <QLineEdit>
#include <QString>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;

}
void MainWindow::on_pushButton_1_clicked()     //登录
{

    if(ui->Line1->text().toLong()==123456789)  //账号正确 ui->Line1->text().toLong()==123456789
    {
        if(ui->Line2->text().toLong()==123456789) //密码正确 ui->Line2->text().toLong()==123456789
        {
            QMessageBox::information(this, tr("黑盒测试用例自动生成系统"), tr("登录成功！欢迎！"));
            ui->Line1->clear();
            ui->Line2->clear();
            new_dialog = new Dialog(this);                       //登录成功 跳转系统内部！
            new_dialog->setModal(true);   //模态
            QObject::connect(this,SIGNAL(on_pushButton_clicked),new_dialog,SLOT(on_pushButton_1_clicked()));
            new_dialog->exec();//question!!

        }

        else if(ui->Line2->text().toLong()==NULL)  //密码为空
        {
            QMessageBox::information(this, tr("黑盒测试用例自动生成系统"), tr("请输入密码！"));
            ui->Line1->clear();
            ui->Line2->clear();
        }
        else       //密码错误
        {
            QMessageBox::information(this, tr("黑盒测试用例自动生成系统"), tr("密码错误！请重试！"));
            ui->Line1->clear();
            ui->Line2->clear();
        }

    }
    else  if(ui->Line1->text().toLong()==NULL)  //账号为空
    {
         QMessageBox::information(this, tr("黑盒测试用例自动生成系统"), tr("请输入账号！"));
         ui->Line1->clear();
         ui->Line2->clear();
    }
    else   //账号不存在
    {
         QMessageBox::information(this, tr("黑盒测试用例自动生成系统"), tr("账号不存在！请重试"));
         ui->Line1->clear();
         ui->Line2->clear();
    }

}




































