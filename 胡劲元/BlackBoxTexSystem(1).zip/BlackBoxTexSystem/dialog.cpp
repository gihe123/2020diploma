#include "dialog.h"
#include "ui_dialog.h"
#include <iostream>
#include <QString>
#include <QMessageBox>
using namespace std;


class ZJ{
public:
    int zj_m;  //取值个数
    int zj_n;  //用例个数
    int zj_k;  //参数个数
    int **zj_chart;

    ZJ(int k,int m,int n,int **chart){
    zj_m = m;
    zj_n = n;
    zj_k = k;

    zj_chart = new int*[zj_n];

    for(int i=0; i<zj_n; i++)
    {
        zj_chart[i] = new int[zj_k];
    }
    for(int i=0; i<zj_n; i++)
    {
        for(int j=0; j<zj_k; j++)
        {
            zj_chart[i][j] = chart[i][j];
        }
    }

    }

};

QList<ZJ> Huge_chart;

const int a1_chart[9][4] = {0,0,0,0,  //4 3 9
                      0,1,2,1,
                      0,2,1,2,
                      1,0,2,2,
                      1,1,1,0,
                      1,2,0,1,
                      2,0,1,1,
                      2,1,0,2,
                      2,2,2,0};
const int a1_chart1[4][3]={0,0,0,   //3 2  4
                          0,1,1,
                          1,0,1,
                          1,1,0};

const int a1_chart2[16][5]={0,0,0,0,0,
                           0,1,1,1,1,
                           0,2,2,2,2,
                           0,3,3,3,3,
                           1,0,1,2,3,
                           1,1,0,3,2,
                           1,2,3,0,1,
                           1,3,2,1,0,
                           2,0,2,3,1,
                           2,1,3,2,0,
                           2,2,0,1,3,
                           2,3,1,0,2,
                           3,0,3,1,2,
                           3,1,2,0,3,
                           3,2,1,3,0,
                           3,3,0,2,1};      //5 4 16
const int a1_chart3[25][6]={0,0,0,0,0,0,
                            0,1,2,3,4,1,
                            0,2,4,1,3,2,
                            0,3,1,4,2,3,
                            0,4,3,2,1,4,
                            1,0,4,3,2,4,
                            1,1,1,1,1,0,
                            1,2,3,4,0,1,
                            1,3,0,2,4,2,
                            1,4,2,0,3,3,
                            2,0,3,1,4,3,
                            2,1,0,4,3,4,
                            2,2,2,2,2,0,
                            2,3,4,0,1,1,
                            2,4,1,3,0,2,
                            3,0,2,4,1,2,
                            3,1,4,2,0,3,
                            3,2,1,0,4,4,
                            3,3,3,3,3,0,
                            3,4,0,1,2,1,
                            4,0,1,2,3,1,
                            4,1,3,0,2,2,
                            4,2,0,3,1,3,
                            4,3,2,1,0,4,
                            4,4,4,4,4,0}; //6 5 25
const int a1_chart4[49][8]={0,0,0,0,0,0,0,0,
                            0,1,2,3,4,5,6,1,
                            0,2,4,6,1,3,5,2,
                            0,3,6,2,5,1,4,3,
                            0,4,1,5,2,6,3,4,
                            0,5,3,1,6,4,2,5,
                            0,6,5,4,3,2,1,6,
                            1,0,6,5,4,3,2,6,
                            1,1,1,1,1,1,1,0,
                            1,2,3,4,5,6,0,1,
                            1,3,5,0,2,4,6,2,
                            1,4,0,3,6,2,5,3,
                            1,5,2,6,3,0,4,4,
                            1,6,4,2,0,5,3,5,
                            2,0,5,3,1,6,4,5,
                            2,1,0,6,5,4,3,6,
                            2,2,2,2,2,2,2,0,
                            2,3,4,5,6,0,1,1,
                            2,4,6,1,3,5,0,2,
                            2,5,1,4,0,3,6,3,
                            2,6,3,0,4,1,5,4,
                            3,0,4,1,5,2,6,4,
                            3,1,6,4,2,0,5,5,
                            3,2,1,0,6,5,4,6,
                            3,3,3,3,3,3,3,0,
                            3,4,5,6,0,1,2,1,
                            3,5,0,2,4,6,1,2,
                            3,6,2,5,1,4,0,3,
                            4,0,3,6,2,5,1,3,
                            4,1,5,2,6,3,0,4,
                            4,2,0,5,3,1,6,5,
                            4,3,2,1,0,6,5,6,
                            4,4,4,4,4,4,4,0,
                            4,5,6,0,1,2,3,1,
                            4,6,1,3,5,0,2,2,
                            5,0,2,4,6,1,3,2,
                            5,1,4,0,3,6,2,3,
                            5,2,6,3,0,4,1,4,
                            5,3,1,6,4,2,0,5,
                            5,4,3,2,1,0,6,6,
                            5,5,5,5,5,5,5,0,
                            5,6,0,1,2,3,4,1,
                            6,0,1,2,3,4,5,1,
                            6,1,3,5,0,2,4,2,
                            6,2,5,1,4,0,3,3,
                            6,3,0,4,1,5,2,4,
                            6,4,2,0,5,3,1,5,
                            6,5,4,3,2,1,0,6,
                            6,6,6,6,6,6,6,0};//8 7 49
const int a2_chart[36][8] = {        // 36  8
    0,0,0,0,0,1,5,5,
    0,0,0,0,1,1,1,2,
    0,0,0,0,2,0,3,1,
    0,0,0,1,0,2,4,3,
    0,0,0,1,2,3,0,2,
    0,0,0,1,2,4,2,0,
    0,0,1,1,0,4,1,4,
    0,0,1,1,1,3,3,5,
    0,0,1,1,2,5,5,3,
    0,1,0,0,1,3,4,0,
    0,1,0,0,1,5,0,4,
    0,1,0,1,0,0,2,4,
    0,1,1,0,0,2,0,0,
    0,1,1,0,1,0,1,3,
    0,1,1,0,2,1,2,1,
    0,1,1,0,2,4,4,5,
    0,1,1,1,0,5,3,2,
    0,1,1,1,1,2,5,1,
    1,0,0,0,0,5,4,1,
    1,0,0,0,2,2,3,4,
    1,0,0,1,1,0,5,0,
    1,0,1,0,0,0,0,5,
    1,0,1,0,0,3,2,3,
    1,0,1,0,1,2,2,2,
    1,0,1,0,2,5,1,0,
    1,0,1,1,1,1,4,4,
    1,0,1,1,1,4,0,1,
    1,1,0,0,0,4,5,2,
    1,1,0,0,1,4,3,3,
    1,1,0,1,0,3,1,1,
    1,1,0,1,1,5,2,5,
    1,1,0,1,2,1,0,3,
    1,1,0,1,2,2,1,5,
    1,1,1,0,2,3,5,4,
    1,1,1,1,0,1,3,0,
    1,1,1,1,2,0,4,2,
};
const int a2_chart1[8][5] = {0,0,0,0,0,
                             0,0,1,1,2,
                             0,1,0,1,1,
                             0,1,1,0,3,
                             1,0,0,1,3,
                             1,0,1,0,1,
                             1,1,0,0,2,
                             1,1,1,1,0};//8 5
const int a2_chart2[12][5] = {0,0,0,0,0,
                              0,0,1,1,1,
                              0,0,1,1,2,
                              0,1,0,0,2,
                              0,1,0,1,0,
                              0,1,1,0,1,
                              1,0,0,0,1,
                              1,0,0,1,2,
                              1,0,1,0,0,
                              1,1,0,1,1,
                              1,1,1,0,2,
                              1,1,1,1,0};// 12 5
const int a2_chart3[12][3] = {0,0,0,
                              0,0,2,
                              0,0,4,
                              0,1,1,
                              0,1,3,
                              0,1,5,
                              1,0,1,
                              1,0,3,
                              1,0,5,
                              1,1,0,
                              1,1,2,
                              1,1,4,
                                    };//12  3
const int a2_chart4[18][7] = {0,0,0,0,0,0,0,
                              0,0,1,1,2,2,1,
                              0,1,0,2,2,1,2,
                              0,1,2,0,1,2,3,
                              0,2,1,2,1,0,4,
                              0,2,2,1,0,1,5,
                              1,0,0,2,1,2,5,
                              1,0,2,0,2,1,4,
                              1,1,1,1,1,1,0,
                              1,1,2,2,0,0,1,
                              1,2,0,1,2,0,3,
                              1,2,1,0,0,2,2,
                              2,0,1,2,0,1,3,
                              2,0,2,1,1,0,2,
                              2,1,0,1,0,2,4,
                              2,1,1,0,2,0,5,
                              2,2,0,0,1,1,1,
                              2,2,2,2,2,2,0
                        };     //18 7
const int a2_chart5[20][3] = {0,0,0,
                              0,0,2,
                              0,0,4,
                              0,0,6,
                              0,0,8,
                              0,1,1,
                              0,1,3,
                              0,1,5,
                              0,1,7,
                              0,1,9,
                              1,0,1,
                              1,0,3,
                              1,0,5,
                              1,0,7,
                              1,0,9,
                              1,1,0,
                              1,1,2,
                              1,1,4,
                              1,1,6,
                              1,1,8};   //20  3
Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    ui->pushButton->setEnabled(false);
    ui->pushButton_2->setEnabled(false);
    ui->pushButton_3->setEnabled(false);
    ui->pushButton_4->setEnabled(false);

    ui->textEdit->setEnabled(false);
    param = 0;
    str_context = "";

}

Dialog::~Dialog()
{
    delete ui;
}

bool find_zj(int k, int m, int n)//k 参数 m 水平 n 用例个数
{

}


void Dialog::on_paramB_clicked()
{
    QString str = ui->lineEdit->text();

    if(str == NULL)
    {
        QMessageBox::warning(this, tr("输入错误"), tr("参数不能为空"));
        return;
    }
    param = ui->lineEdit->text().toInt();//健壮性

    cout << param << endl;
    QMessageBox::information(this, tr("黑盒测试用例自动生成系统"), tr("参数数目录入成功，请继续！"));

    ui->textEdit->setEnabled(true);
    ui->paramB->setEnabled(false);
    ui->lineEdit->setEnabled(false);
}

void Dialog::on_textButton_clicked()
{
    str_context = ui->textEdit->toPlainText();
    if(str_context == NULL)
    {
        QMessageBox::warning(this, tr("输入错误"), tr("文本不能为空!"));
        return;
    }
    //qDebug() << str_context << endl;


    QList<QString> temp_list = str_context.split("\n");//健壮性

    for(int j=0; j<temp_list.size(); j++)
    {
      //qDebug() << temp_list[j] << endl;

      QList<QString> temp2_list = temp_list[j].remove(QRegExp("\\s")).split(",",QString::SkipEmptyParts);//正则表达式
      vec.append(temp2_list);
    }

//    for(int i=0; i<vec.size(); i++)
//    {
//      //qDebug() << temp_list[j] << endl;
//      qDebug() << vec[i] << "number" << vec[i].size() << endl;
//    }
    if(temp_list.size()!=param)
    {
        QMessageBox::warning(this, tr("输入错误"), tr("参数个数与参数群不符！请重试！"));
        ui->textEdit->clear();
    }
    else
    {

        QMessageBox::information(this, tr("黑盒测试用例自动生成系统"), tr("功能数据群处理成功，请继续！"));
        ui->textEdit->setEnabled(false);
        ui->textButton->setEnabled(false);

        ui->pushButton->setEnabled(true);
        ui->pushButton_2->setEnabled(true);
        ui->pushButton_3->setEnabled(true);
        ui->pushButton_4->setEnabled(true);

        str_context = ui->textEdit->toPlainText();

        QList<QString> temp_list2 = str_context.split("\n");//健壮性

        for(int j=0; j<temp_list2.size(); j++)
        {
          //qDebug() << temp_list[j] << endl;

          QList<QString> temp2_list = temp_list2[j].remove(QRegExp("\\s")).split(",",QString::SkipEmptyParts);//正则表达式
          vec2.append(temp2_list);
        }
        //qDebug()<<vec2.size()<<endl;
    }


}

void Dialog::get(int i,QString str,QList<QList<QString>> list,int param,int *n)
{
    if(i == param)
    {
        //qDebug()<<str<<endl;
        this->new_list.append(str);
        str = "";
        *n = *n+1;
        return ;
    }
    for(int k=0; k<list[i].size();k++)
    {
        QString temp = str;
        str+= list[i].at(k) + " ";

        get(i+1,str,list,param,n);

        str= temp;
    }
}

void Dialog::on_pushButton_clicked()
{
    ui->textBrowser->clear();


    int num = 1;
    for(int i=0; i<param; i++)
    {
        num *= vec[i].size();
    }
    QString str = "";
    int *n=new int;
    *n = 0;

    get(0,str,vec,param,n);
    //qDebug()<<*n<<endl;

//    qDebug()<<this->new_list.size()<<endl;
//    qDebug()<<this->new_list<<endl;
    QMessageBox::information(this, tr("黑盒测试用例自动生成系统"), tr("正在处理数据群，请稍后！"));
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("                      黑盒测试用例自动生成系统                       ");
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("                                                                ");
    ui->textBrowser->append("                                                                ");
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("              黑盒测试用例全组合结果生成完成，结果如下：                ");
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("                                                                ");
    ui->textBrowser->append("                 全组合生成测试用例共有"+QString::number(new_list.size())+"种结果如下：");
    ui->textBrowser->append("                                                                ");
    for(int i=0; i<new_list.size(); i++)
    {
        ui->textBrowser->append("                            "+this->new_list[i]);
    }
}

bool VerifyNumber(QString str)
{
    std::string temp = str.toStdString();
    for (int i = 0; i < str.length(); i++)
    {
        if (temp[i]<'0' || temp[i]>'9')
        {
            return false;
        }
    }
    return true;
}

void Dialog::on_pushButton_2_clicked()
{
    ui->textBrowser->setText("");
    QList<QList<QString>> new_vec = vec2;
    for(int i=0; i<vec2.size(); i++)
    {
        if(VerifyNumber(vec2[i].at(0)))
        {
            for(int k=0; k<vec2[i].size(); k++)
            {
                new_vec[i].append(QString::number(vec2[i].at(k).toDouble()+1));
                new_vec[i].append(QString::number(vec2[i].at(k).toDouble()-1));
            }
            //ui->textBrowser->append("true");
        }
    }
//    for(int i=0; i<new_vec.size(); i++)
//    {
//        for(int j=0; j<new_vec[i].size();j++)
//        {
//        ui->textBrowser->append(new_vec[i].at(j));
//        }
//    }
    QString str = "";
    int *n=new int;
    *n = 0;
    new_list.clear();
    get(0,str,new_vec,param,n);
    QMessageBox::information(this, tr("黑盒测试用例自动生成系统"), tr("正在处理数据群，请稍后！"));
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("                      黑盒测试用例自动生成系统                       ");
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("                                                                ");
    ui->textBrowser->append("                                                                ");
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("              黑盒测试用例边界值结果生成完成，结果如下：                ");
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("                                                                ");
    ui->textBrowser->append("                 边界值生成测试用例共有"+QString::number(new_list.size())+"种结果如下：");
    for(int i=0; i<new_list.size(); i++)
    {
        ui->textBrowser->append("                            "+this->new_list[i]);
    }
}

void Dialog::on_pushButton_4_clicked()
{
    this->close();
}

void Dialog:: Display()
{
    QMessageBox::information(this, tr("黑盒测试用例自动生成系统"), tr("正在处理数据群，请稍后！"));
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("                      黑盒测试用例自动生成系统                       ");
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("                                                                ");
    ui->textBrowser->append("                                                                ");
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("              黑盒测试用例正交试验法结果生成完成，结果如下：                ");
    ui->textBrowser->append("================================================================");
    ui->textBrowser->append("                                                                ");
}

void Dialog::on_pushButton_3_clicked()
{
    ui->textBrowser->clear();
    int k = vec2.size();//参数个数
    int countm = vec2[0].size();
    bool flag = true;
    QList<int> num_size;

    for(int i=1; i<k; i++)
    {
       if(countm != vec2[i].size())
       {
           flag = false;
           break;
       }
    }

    if(flag)
    {
        //水平相等
        int m = vec2[0].size();
        int n = k*(m-1)+1;

//-------------------------------------------------------------------------------------------------
        if((k==4) && (m<=3))      // 4 3
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart[i][j]>=m)
                 {
                     str += vec2[j].at(0)+" ";//随机函数
                 }
                 else{
                 str += vec2[j].at(a1_chart[i][j])+" ";
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==3) && (m<=3))      // 3 3
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart[i][j]>=m)
                 {
                     str += vec2[j].at(0)+" ";//随机函数
                 }
                 else{
                 str += vec2[j].at(a1_chart[i][j])+" ";
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==3) && (m<=2))      // 3 2
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart1[i][j]>=m)
                 {
                     str += vec2[j].at(0)+" ";//随机函数
                 }
                 else{
                 str += vec2[j].at(a1_chart1[i][j])+" ";
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==5) && (m<=4))      // 5 4
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart2[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";//随机函数
                 }
                 else{
                 str += vec2[j].at(a1_chart2[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==4) && (m<=4))      // 4 4
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart2[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";//随机函数
                 }
                 else{
                 str += vec2[j].at(a1_chart2[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==3) && (m<=4))      // 3 4
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart2[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";//随机函数
                 }
                 else{
                 str += vec2[j].at(a1_chart2[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==6) && (m<=5))      // 6  5
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart3[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";
                 }
                 else{
                 str += vec2[j].at(a1_chart3[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==5) && (m<=5))      // 5  5
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart3[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";
                 }
                 else{
                 str += vec2[j].at(a1_chart3[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==4) && (m<=5))      // 4  5
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart3[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";
                 }
                 else{
                 str += vec2[j].at(a1_chart3[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==3) && (m<=5))      // 3  5
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart3[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";
                 }
                 else{
                 str += vec2[j].at(a1_chart3[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==8) && (m<=7))      // 8  7
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart4[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";
                 }
                 else{
                 str += vec2[j].at(a1_chart4[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==7) && (m<=7))      // 7  7
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart4[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";
                 }
                 else{
                 str += vec2[j].at(a1_chart4[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==6) && (m<=7))      // 6  7
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart4[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";
                 }
                 else{
                 str += vec2[j].at(a1_chart4[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==5) && (m<=7))      // 5  7
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart4[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";
                 }
                 else{
                 str += vec2[j].at(a1_chart4[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==4) && (m<=7))      // 4  7
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart4[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";
                 }
                 else{
                 str += vec2[j].at(a1_chart4[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else if((k==3) && (m<=7))      // 3  7
        {
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<n; i++)
            {
                QString str = "";
                for(int j=0; j<k; j++)
                {
                 if(a1_chart4[i][j]>=m) //
                 {
                     str += vec2[j].at(0)+" ";
                 }
                 else{
                 str += vec2[j].at(a1_chart4[i][j])+" ";//
                 }
                }
                ui->textBrowser->append("                            "+str);

            }
        }
//-------------------------------------------------------------------------------------------------
        else
        {
            QMessageBox::warning(this, tr("Question"), tr("无合适替代正交表，请重试！"));
            ui->lineEdit->clear();
            ui->textEdit->clear();
        }

        //
    }
    else
    {   //水平不相等

//-------------------------------------------------------------------------------------------------
        if(k == 8)//                                 //  36  8
        {
            int n = 36;//
            Display();
            ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
            ui->textBrowser->append("                                                                ");
            for(int i=0; i<k; i++)
            {
               num_size.append(vec2[i].size());
               qDebug() << num_size[i];
            }
            for(int i=0; i<n; i++)
            {//大循环
                    QString str = "";
                for(int j=0;j<k;j++)
                {
                    if(num_size[j] == 2)//
                    {
                        if(a2_chart[i][j]<2)//
                        str += vec2[j].at(a2_chart[i][j])+" ";
                        else str += vec2[j].at(0)+" ";
                    }
                }

                for(int j=0;j<k;j++)
                {
                    if(num_size[j] == 3)
                    {
                        if(a2_chart[i][j]<3)
                        str += vec2[j].at(a2_chart[i][j])+" ";
                        else str += vec2[j].at(0)+" ";
                    }
                }
                for(int j=0;j<k;j++)
                {
                    if(num_size[j] == 6)
                    {
                        if(a2_chart[i][j]<6)
                        str += vec2[j].at(a2_chart[i][j])+" ";
                        else str += vec2[j].at(0)+" ";
                    }
            }
            ui->textBrowser->append("                         "+str);

            }

        }
//-------------------------------------------------------------------------------------------------
        else if(k == 5&&vec2[4].size()==4)//                                 //  8   5
        {
            int n = 8;//
            if(1)
            {
                Display();
                ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
                ui->textBrowser->append("                                                                ");
                for(int i=0; i<k; i++)
                {
                   num_size.append(vec2[i].size());
                   qDebug() << num_size[i];
                }
                for(int i=0; i<n; i++)
                {//大循环
                        QString str = "";
                    for(int j=0;j<k;j++)
                    {
                        if(num_size[j] == 2)//
                        {
                            if(a2_chart1[i][j]<2)//
                            str += vec2[j].at(a2_chart1[i][j])+" ";  //
                            else str += vec2[j].at(0)+" ";
                        }
                    }

                    for(int j=0;j<k;j++)
                    {
                        if(num_size[j] == 4)
                        {
                            if(a2_chart1[i][j]<4)  //
                            str += vec2[j].at(a2_chart1[i][j])+" ";//
                            else str += vec2[j].at(0)+" ";
                        }
                    }

                ui->textBrowser->append("                         "+str);

                }
            }

        }
//-------------------------------------------------------------------------------------------------
        else if(k == 5&&vec2[4].size()==3)//                                 //  12   5
        {
            int n = 12;//
            if(1)
            {
                Display();
                ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
                ui->textBrowser->append("                                                                ");
                for(int i=0; i<k; i++)
                {
                   num_size.append(vec2[i].size());
                   qDebug() << num_size[i];
                }
                for(int i=0; i<n; i++)
                {//大循环
                        QString str = "";
                    for(int j=0;j<k;j++)
                    {
                        if(num_size[j] == 2)//
                        {
                            if(a2_chart2[i][j]<2)//
                            str += vec2[j].at(a2_chart2[i][j])+" ";  //
                            else str += vec2[j].at(0)+" ";
                        }
                    }

                    for(int j=0;j<k;j++)
                    {
                        if(num_size[j] == 3)
                        {
                            if(a2_chart2[i][j]<3)  //
                            str += vec2[j].at(a2_chart2[i][j])+" ";//
                            else str += vec2[j].at(0)+" ";
                        }
                    }

                ui->textBrowser->append("                         "+str);

                }

            }

        }
//-------------------------------------------------------------------------------------------------
        else if(k == 3&&vec2[2].size()==6)//                                 //  12   3
        {
            int n = 12;//
            if(1)
            {
                Display();
                ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
                ui->textBrowser->append("                                                                ");
                for(int i=0; i<k; i++)
                {
                   num_size.append(vec2[i].size());
                   qDebug() << num_size[i];
                }
                for(int i=0; i<n; i++)
                {//大循环
                        QString str = "";
                    for(int j=0;j<k;j++)
                    {
                        if(num_size[j] == 2)//
                        {
                            if(a2_chart3[i][j]<2)//
                            str += vec2[j].at(a2_chart3[i][j])+" ";  //
                            else str += vec2[j].at(0)+" ";
                        }
                    }

                    for(int j=0;j<k;j++)
                    {
                        if(num_size[j] == 6)
                        {
                            if(a2_chart3[i][j]<6)  //
                            str += vec2[j].at(a2_chart3[i][j])+" ";//
                            else str += vec2[j].at(0)+" ";
                        }
                    }

                ui->textBrowser->append("                         "+str);

                }

            }

        }
//-------------------------------------------------------------------------------------------------
        else if(k == 7)//                                 //  18   7
        {
            int n = 18;//
            if(n==18)
            {
                Display();
                ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
                ui->textBrowser->append("                                                                ");
                for(int i=0; i<k; i++)
                {
                   num_size.append(vec2[i].size());
                   qDebug() << num_size[i];
                }
                for(int i=0; i<n; i++)
                {//大循环
                        QString str = "";
                    for(int j=0;j<k;j++)
                    {
                        if(num_size[j] == 3)//
                        {
                            if(a2_chart4[i][j]<3)//
                            str += vec2[j].at(a2_chart4[i][j])+" ";  //
                            else str += vec2[j].at(0)+" ";
                        }
                    }

                    for(int j=0;j<k;j++)
                    {
                        if(num_size[j] == 6)
                        {
                            if(a2_chart4[i][j]<6)  //
                            str += vec2[j].at(a2_chart4[i][j])+" ";//
                            else str += vec2[j].at(0)+" ";
                        }
                    }

                ui->textBrowser->append("                         "+str);

                }
            }

        }
//-------------------------------------------------------------------------------------------------
        else if(k == 3&&vec2[2].size()==10)//                                 //  20   3
        {
            int n = 20;//
            if(1)
            {
                Display();
                ui->textBrowser->append("                 正交试验法测试用例共有"+QString::number(n)+"种结果如下：");
                ui->textBrowser->append("                                                                ");
                for(int i=0; i<k; i++)
                {
                   num_size.append(vec2[i].size());
                   qDebug() << num_size[i];
                }
                for(int i=0; i<n; i++)
                {//大循环
                        QString str = "";
                    for(int j=0;j<k;j++)
                    {
                        if(num_size[j] == 2)//
                        {
                            if(a2_chart5[i][j]<2)//
                            str += vec2[j].at(a2_chart5[i][j])+" ";  //
                            else str += vec2[j].at(0)+" ";
                        }
                    }

                    for(int j=0;j<k;j++)
                    {
                        if(num_size[j] == 10)
                        {
                            if(a2_chart5[i][j]<10)  //
                            str += vec2[j].at(a2_chart5[i][j])+" ";//
                            else str += vec2[j].at(0)+" ";
                        }
                    }

                ui->textBrowser->append("                         "+str);

                }
            }

        }
//-------------------------------------------------------------------------------------------------
        else
        {
            QMessageBox::warning(this, tr("Question"), tr("无合适替代正交表，请重试！"));
            ui->lineEdit->clear();
            ui->textEdit->clear();
        }

    }


}
