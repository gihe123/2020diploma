#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QString>
#include <QDebug>
#include <QList>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();
    int param;
    QString str_context;
    QList<QList<QString>> vec;//分割后的
    QList<QList<QString>> vec2;
    QList<QString> new_list;//生成的全组合

    void get(int i, QString str, QList<QList<QString>> list, int param, int *n);
    void Display();


private slots:
    void on_paramB_clicked();

    void on_textButton_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::Dialog *ui;
};

#endif // DIALOG_H
