package com.cdz.o2o.dao;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cdz.o2o.entity.Area;


@RunWith(SpringRunner.class)
@SpringBootTest
public class AreaDaoTest {
	
	@Autowired
	private AreaDao areaDao;
	

	@Ignore
	public void testAInsertArea() throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/o2o?useUnicode=true&characterEncoding=utf-8&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","root");
		Statement statement=connection.createStatement();
		System.out.println(connection.isClosed());
	}
	
	@Test
	public void testBQueryArea() throws Exception {
		List<Area> areaList = areaDao.queryArea();
		assertEquals(4, areaList.size());
	}

}
