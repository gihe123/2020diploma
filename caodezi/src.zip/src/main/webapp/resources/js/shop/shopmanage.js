$(function(){
	var shopId = getQueryString('shopId');
	$("#shopInfo").attr("href","/myo2o/shop/shopedit?shopId="+shopId);
});