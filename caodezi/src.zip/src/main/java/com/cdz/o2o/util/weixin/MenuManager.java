package com.cdz.o2o.util.weixin;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cdz.o2o.util.weixin.message.pojo.AccessToken;
import com.cdz.o2o.util.weixin.message.pojo.Button;
import com.cdz.o2o.util.weixin.message.pojo.CommonButton;
import com.cdz.o2o.util.weixin.message.pojo.ComplexButton;
import com.cdz.o2o.util.weixin.message.pojo.Menu;
import com.cdz.o2o.util.weixin.message.pojo.ViewButton;

/**
 * 菜单管理器类
 * 
 */
public class MenuManager {
	private static Logger log = LoggerFactory.getLogger(MenuManager.class);

	public static void main(String[] args) throws UnsupportedEncodingException {
		// 第三方用户唯一凭证
		String appId = "wxf9a1694592964599";
		// 第三方用户唯一凭证密钥
		String appSecret = "f7691799f2963173a410c6482df0f1f3";

		// 调用接口获取access_token
		AccessToken at = WeixinUtil.getAccessToken(appId, appSecret);

		if (null != at) {
			// 调用接口创建菜单
			int result = WeixinUtil.createMenu(getMenu(), at.getToken());

			// 判断菜单创建结果
			if (0 == result)
				log.info("菜单创建成功！");
			else
				log.info("菜单创建失败，错误码：" + result);
		}
	}

	/**
	 * 组装菜单数据
	 * 
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	private static Menu getMenu() throws UnsupportedEncodingException {

		ViewButton mainbutton1 = new ViewButton();
		mainbutton1.setName("游客入口");
		mainbutton1.setType("view");
		String codeUrl = 
				"https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxf9a1694592964599&redirect_uri=http://www.cdzproject.xyz/myo2o/wechatlogin/logincheck&role_type=1&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect";
		mainbutton1.setUrl(codeUrl);
		
		ViewButton mainbutton2 = new ViewButton();
		mainbutton2.setName("商家入口");
		mainbutton2.setType("view");
		 codeUrl = 
				"https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxf9a1694592964599&redirect_uri=http://www.cdzproject.xyz/myo2o/wechatlogin/logincheck&role_type=1&response_type=code&scope=snsapi_userinfo&state=2#wechat_redirect";
		 mainbutton2.setUrl(codeUrl);
		

		/**
		 * 这是公众号xiaoqrobot目前的菜单结构，每个一级菜单都有二级菜单项<br>
		 * 
		 * 在某个一级菜单下没有二级菜单的情况，menu该如何定义呢？<br>
		 * 比如，第三个一级菜单项不是“更多体验”，而直接是“幽默笑话”，那么menu应该这样定义：<br>
		 * menu.setButton(new Button[] { mainBtn1, mainBtn2, btn33 });
		 */
		Menu menu = new Menu();
		menu.setButton(new Button[] { mainbutton1, mainbutton2});

		return menu;
	}
}