package com.cdz.o2o.service;

import com.cdz.o2o.dto.UserShopMapExecution;
import com.cdz.o2o.entity.UserShopMap;

public interface UserShopMapService {

	UserShopMapExecution listUserShopMap(UserShopMap userShopMapCondition,
			int pageIndex, int pageSize);

}
