package com.cdz.o2o.util.weixin.message.pojo;

/** 
 * 按钮的基类 
 *  
 * @author xiang li 
 * @date 2015-02-11 
 */  
public class Button {  
    private String name;  
  
    public String getName() {  
        return name;  
    }  
  
    public void setName(String name) {  
        this.name = name;  
    }  
}  
