package com.cdz.o2o.config.web;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.cdz.o2o.interceptor.shop.ShopLoginInterceptor;
import com.cdz.o2o.interceptor.shop.ShopPermissionInterceptor;
import com.cdz.o2o.interceptor.superadmin.SuperAdminLoginInterceptor;
import com.google.code.kaptcha.servlet.KaptchaServlet;
@Configuration
@EnableWebMvc
public class MvcConfiguration extends WebMvcConfigurerAdapter implements ApplicationContextAware{
	private ApplicationContext ApplicationContext;
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.ApplicationContext=applicationContext;
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		//registry.addResourceHandler("/resources/**").addResourceLocations("classpath:/resources/");
		//window环境下的图片存储路径
		//registry.addResourceHandler("/upload/**").addResourceLocations("file:D:/projectdev/image/upload/");
		//linux环境下的文件存储路径
		registry.addResourceHandler("/upload/**").addResourceLocations("file:/Users/baidu/work/image/upload/");

	}
	
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}
	
	@Bean(name="viewResolver")
	public ViewResolver createViewResolver() {
		InternalResourceViewResolver viewResolver=new InternalResourceViewResolver();
		viewResolver.setApplicationContext(this.ApplicationContext);
		viewResolver.setCache(false);
		viewResolver.setPrefix("/WEB-INF/html/");
		viewResolver.setSuffix(".html");
		return viewResolver;
	}
	
	@Bean(name="multipartResolver")
	public CommonsMultipartResolver createMultipartResolver() {
		CommonsMultipartResolver multipartResolver=new CommonsMultipartResolver();
		multipartResolver.setDefaultEncoding("utf-8");
		multipartResolver.setMaxUploadSize(20971520);
		multipartResolver.setMaxInMemorySize(20971520);
		return multipartResolver;
	}
	
	@Value("${kaptcha.border}")
	private String border;
	
	@Value("${kaptcha.textproducer.font.color}")
	private String fcolor;
	@Value("${kaptcha.image.width}")
	private String width;
	@Value("${kaptcha.textproducer.char.string}")
	private String cString;
	@Value("${kaptcha.image.height}")
	private String height;
	@Value("${kaptcha.textproducer.font.size}")
	private String fsize;
	@Value("${kaptcha.noise.color}")
	private String nColor;
	@Value("${kaptcha.textproducer.char.length}")
	private String clength;
	@Value("${kaptcha.textproducer.font.names}")
	private String fnames;
	
	@Bean
	public ServletRegistrationBean servletRegistrationBean() {
		ServletRegistrationBean servlet=new ServletRegistrationBean(new KaptchaServlet(),"/Kaptcha");
		servlet.addInitParameter("kaptcha.border", border);
		servlet.addInitParameter("kaptcha.textproducer.font.color", fcolor);
		servlet.addInitParameter("kaptcha.image.width", width);
		servlet.addInitParameter("kaptcha.textproducer.char.string", cString);
		servlet.addInitParameter("kaptcha.image.height", height);
		servlet.addInitParameter("kaptcha.textproducer.font.size", fsize);
		servlet.addInitParameter("kaptcha.noise.color", nColor);
		servlet.addInitParameter("kaptcha.textproducer.char.length", clength);
		servlet.addInitParameter("kaptcha.textproducer.font.names", fnames);
		return servlet;
	}
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		String interceptPath="/shop/**";
		InterceptorRegistration loginIR=registry.addInterceptor(new ShopLoginInterceptor());//要求有user的信息才能访问
		loginIR.addPathPatterns(interceptPath);
		loginIR.excludePathPatterns("/shop/ownerlogin");
		loginIR.excludePathPatterns("/shop/ownerlogincheck");
		loginIR.excludePathPatterns("/shop/logout");
		loginIR.excludePathPatterns("/shop/register");
		loginIR.excludePathPatterns("/shop/ownerregister");
		loginIR.excludePathPatterns("/shop/addshopauthmap");
		InterceptorRegistration permissionIR=registry.addInterceptor(new ShopPermissionInterceptor());//要求有shop的信息才能访问
		permissionIR.addPathPatterns(interceptPath);
		permissionIR.excludePathPatterns("/shop/ownerregister");
		permissionIR.excludePathPatterns("/shop/ownerlogin");
		permissionIR.excludePathPatterns("/shop/ownerlogincheck");
		permissionIR.excludePathPatterns("/shop/register");
		permissionIR.excludePathPatterns("/shop/shoplist");
		permissionIR.excludePathPatterns("/shop/logout");
		permissionIR.excludePathPatterns("/shop/list");
		permissionIR.excludePathPatterns("/shop/changepsw");
		permissionIR.excludePathPatterns("/shop/changelocalpwd");
		permissionIR.excludePathPatterns("/shop/ownerbind");
		permissionIR.excludePathPatterns("/shop/bindlocalauth");
		permissionIR.excludePathPatterns("/shop/shopmanage");
		permissionIR.excludePathPatterns("/shop/shopedit");
		permissionIR.excludePathPatterns("/shop/getshopbyid");
		permissionIR.excludePathPatterns("/shop/getshopinitinfo");
		permissionIR.excludePathPatterns("/shop/registershop");
		permissionIR.excludePathPatterns("/shop/addshopauthmap");
		
		InterceptorRegistration superadminIR=registry.addInterceptor(new SuperAdminLoginInterceptor());//要求管理员才能访问
		superadminIR.addPathPatterns("/superadmin/**");
		superadminIR.excludePathPatterns("/superadmin/login");
		superadminIR.excludePathPatterns("/superadmin/logincheck");
		superadminIR.excludePathPatterns("/superadmin/main");
		superadminIR.excludePathPatterns("/superadmin/top");

		
	}
}
