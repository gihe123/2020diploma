package com.cdz.o2o.util.weixin.message.pojo;

/** 
 * 菜单 
 *  
 * @author xiangli 
 * @date 2015-02-11 
 */  
public class Menu {  
    private Button[] button;  
  
    public Button[] getButton() {  
        return button;  
    }  
  
    public void setButton(Button[] button) {  
        this.button = button;  
    }  
}  
